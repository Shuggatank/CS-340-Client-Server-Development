from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animals collection in MongoDB """
    
    def __init__(self, username = None, password = None):
        # Initializing the MongoClient. This helps to
        # access the MongoDB databases and collections.
        self.client = MongoClient('mongodb://%s:%s@localhost:56223/AAC' % (username, password))
        # access the AAC database
        self.database = self.client['AAC']
        print("logged in")
    
    # Create method
    def create(self, data):
        if data is not None:
            insert = self.database.animals.insert(data)
            if insert!=0:
                return True
            else:
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")
   
    #Read method        
    def read(self, criteria=None):
         # {'_id':False} just omits the unique ID of each row  
        if criteria:
            data = self.database.animals.find(criteria, {"_id":False})
        else:
            data = self.database.animals.find({}, {"_id":False})
        return data

    #Update method
    def update(self, update, newUpdate):
        if update is not None:
            update = self.database.animals.update_one(update,{'$set':newUpdate})
#             print(update)
            if update != 0:
                return update
            else:
                return False
        else:
            raise Exception("No record to found")
           
        
    #Delete method
    def delete(self, delete):
        if delete is not None:
            deleted = self.database.animals.remove(delete)
            if deleted !=0:
                return deleted
            else:
                raise Exception("No record found")
        else:
            raise Exception("No criteria provided")
